## v1.4.1

You can now rebind your flashlight toggle key from the in-game rebind settings! It should be the last one at the bottom. :)  

Quick fix in .1, sorry!

## v1.3.1

Made it so flashlight does not activate when using terminal / chat or game is unfocused

## v1.2.0

Fixed keeping flashlight ability after respawning (with biggerlobby)

## v1.1.0

Fixed battery not being checked

Fixed Server flashlight not syncing with client flashlight
