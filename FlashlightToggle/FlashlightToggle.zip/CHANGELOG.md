
## v1.2.0

Fixed keeping flashlight ability after respawning (with biggerlobby)

## v1.1.0

Fixed battery not being checked

Fixed Server flashlight not syncing with client flashlight
