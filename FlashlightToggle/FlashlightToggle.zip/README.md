
# Flashlight Toggle

## Press F to toggle your most recently held flashlight in your inventory

Works if you are holding another item or the flashlight itself.

All players must have the mod installed. (maybe havent tested. server owner for sure though)
