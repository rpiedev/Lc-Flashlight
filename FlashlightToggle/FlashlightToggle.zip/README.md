
# Flashlight Toggle

## Press F to toggle your most recently held flashlight in your inventory

## Rebind from the in-game menu! 

Works if you are holding another item or the flashlight itself.

FULLY CLIENT SIDE!

Rebind from the ingame rebind settings menu, should be at the bottom of the list
